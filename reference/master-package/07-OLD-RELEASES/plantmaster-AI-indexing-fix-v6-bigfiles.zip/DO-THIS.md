# AI Indexing Fix v6 — the big-file fix (no more 10-minute stalls)

## What was wrong
Small manuals are fast now (they go inline). But the 14.8 MB one stalled:
every automatic retry was RE-UPLOADING it as a brand-new file, so Gemini
restarted processing from zero every time and never finished.

## What v6 does
1. **File reuse**: the uploaded file is tagged per manual. On retry the
   function FINDS the already-uploaded file and keeps waiting on it —
   no re-upload, no restart.
2. **12 MB inline threshold** (was 4 MB): any PDF up to 12 MB now skips the
   file-upload step entirely → most manuals index in under a minute.
3. **8 automatic background retries** (was 4) with smarter waiting.

Expected: 14.8 MB manual finishes in roughly 2–4 minutes now.

## Deploy (2 steps)
1. Supabase → Edge Functions → **ingest-manual** → Code tab → delete all →
   paste entire `supabase-functions/ingest-manual.ts` → **Deploy** (Verify JWT ON)
2. GitHub → upload `app.js` → Commit → upload `index.html` → Commit

## Test
- Close app fully → reopen → Manuals
- Tap 🤖 Index for AI on the big PDF. Watch: indexing… (maybe a retry or
  two) → indexed within a few minutes.
- Any manual under 12 MB now indexes fast by itself.
