# PlantMaster Pro v9 — the five fixes you listed

1. **Daily Plant Report (email)** — now professional:
   - Auto-generates the full email from TODAY's live data: work orders
     (done/open/overdue), alarms, checklists, attendance, daily logs, machines
   - You (engineer) are the reviewer: it opens in a clean editable report,
     you read/edit it, then tap "Reviewed — Send from Email App".
     Nothing is sent without your tap.
   - Recipient pre-fills from your company profile email.
2. **Push notifications** — dashboard now shows an alerts bar:
   - Amber "Push alerts are off → Enable alerts" button (one tap)
   - Green "Push alerts enabled" when on
   - If permission was already given once, it now subscribes automatically
     (the old "Later" button trapped it off for 24h — removed)
3. **Platform Admin removed from the customer app** — it lives in the
   Control Center only. The drawer no longer shows it.
4. **Add Worker / toolbar buttons** — text no longer wraps or misaligns
   on phone widths.
5. **Scanner on the Dashboard** — new 📷 Scanner card (right after Work
   Orders) opens the Unified Scanner.

Nothing else was changed.

## Deploy (4 files → GitHub)
Upload each to the repo (Add file → Upload files → Commit):
1. `app.js`
2. `operations.js`
3. `index.html`
4. `push-client.js`   (replaces the old v1.0.0 file)

No SQL, no Supabase function changes.

## Test checklist
- [ ] Dashboard: 📷 Scanner card present → tap → scanner opens
- [ ] Dashboard: alerts bar present → tap "Enable alerts" → allow in the
      phone popup → bar turns GREEN "Push alerts enabled"
      (test a push later: create a checklist failure or a work order —
      you should get a phone notification even with the app closed)
- [ ] Drawer (☰): no more "Platform Admin"
- [ ] People → Members: "＋ Add Worker" button on one line, aligned
- [ ] More → Daily Email: opens "Daily Plant Report" → auto-filled report
      with today's numbers → edit if needed → tap Reviewed → email app opens
- [ ] Problem Solver, Manuals, voice: unchanged and working
