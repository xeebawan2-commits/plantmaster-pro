# PlantMaster Pro — v9.1.2: notification-click 404 fix

Push is WORKING (notification arrived 🎉). This tiny package fixes the last detail:
tapping a notification used to open `hsbfix.org/notifications` (a 404). Now it opens the
app and lands directly on the right screen (Alerts).

**Replace 3 files** (same repo, same way: open → ✏️ → select all → paste → Commit):
1. `service-worker.js`  ← new one from this zip
2. `app.js`             ← new one from this zip
3. `index.html`         ← new one from this zip

**Test:**
1. Wait 1–10 min → open hsbfix.org → refresh twice
2. Supabase SQL → run the test insert again (see v9.1.1 guide)
3. Actions → Push poller → Run workflow
4. Lock phone → notification → **TAP IT**
5. ✅ App opens **directly on the Alerts screen** (no 404)

(No SQL, no Supabase functions, no poller changes — just these 3 files.)
