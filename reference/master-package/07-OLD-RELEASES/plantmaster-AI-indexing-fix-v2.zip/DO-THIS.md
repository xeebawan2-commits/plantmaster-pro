# AI Indexing Fix (v2) — auto-indexing + status line

## What was wrong
Gemini changed its file-upload format — the old inline upload now fails with
"Unknown name content". The new `ingest-manual.ts` uses Gemini's official
multipart upload. (Also fixed two internal file-URL bugs.)

## What's new in the app
1. **Automatic indexing**: upload a PDF manual → it indexes in the background
   automatically (no button needed). You still see progress on the card:
   `uploaded → indexing… → indexed` (or `index failed — tap to retry`).
2. The 🤖 Index for AI button stays for re-indexing / retrying failed ones.
3. Over-20 MB PDFs: upload works, but indexing needs parts (a toast tells you).

## Deploy (3 steps)

**1. Supabase — update the function:**
- Edge Functions → `ingest-manual` → **Code** tab
- Delete everything → paste the ENTIRE `supabase-functions/ingest-manual.ts` → **Deploy**
- Verify JWT stays ON. No new secrets.

**2. GitHub — upload 2 files:**
- `app.js` → Add file → Upload files → Commit
- `index.html` → Add file → Upload files → Commit

**3. Test:**
- Wait 1–2 minutes → close the app fully → reopen
- Manuals & Drawings → tap **🤖 Index for AI** on your existing
  `9829305005.pdf` (14.8 MB) → the card now shows **indexing…**
- Wait for the "Done — N text chunks ready" toast → status becomes **indexed**
- From now on, NEW manual uploads start indexing automatically
- Then ask the Problem Solver a question from that manual — it should answer
  with "manual — page n" citations

## If it fails again
The exact error shows in the toast (and status becomes `index failed — tap to retry`).
Send me the exact error text. Common ones:
- "password-protected or corrupted" → the PDF is locked/corrupt
- "over 20 MB" / "pages (max 150)" → split the PDF
- "still processing" → press Index again after a minute
