import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// PlantMaster Pro — ingest-manual (v2: correct Gemini multipart upload)
// Reads a PDF from the plant-files bucket, extracts its text with Gemini
// (page by page) and stores chunks in document_chunks so the AI deep search
// can read the manual's contents.
// Called from the app with a user JWT (auto-runs after upload; button = re-index).
// Owner/manager only. Verify JWT: ON.

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization,x-client-info,apikey,content-type" };
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

function serverSecret() {
  const d = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SUPABASE_SECRET_KEY");
  if (d) return d;
  try {
    const p = JSON.parse(Deno.env.get("SUPABASE_SECRET_KEYS") || "{}");
    const v = (Array.isArray(p) ? p : Object.values(p || {})).flatMap((x: any) => typeof x === "string" ? [x] : Object.values(x || {}).filter((y): y is string => typeof y === "string"));
    const modern = v.find((x: string) => x.startsWith("sb_secret_"));
    if (modern) return modern;
    return v.find((x: string) => { try { return JSON.parse(atob(x.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))).role === "service_role"; } catch { return false; } });
  } catch { return; }
}

const MAX_PAGES = 150;      // bigger PDFs: split into parts first
const BATCH_PAGES = 25;     // pages per Gemini extraction call
const DEADLINE_MS = 130000; // stay under the platform's function time limit

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const started = Date.now();
  try {
    const key = Deno.env.get("GEMINI_API_KEY");
    const url = Deno.env.get("SUPABASE_URL");
    const secret = serverSecret();
    const authorization = req.headers.get("Authorization") || "";
    const apikey = req.headers.get("apikey") || "";
    const jwt = authorization.replace(/^Bearer\s+/i, "");
    if (!key) throw Error("GEMINI_API_KEY secret is missing");
    if (!url || !secret) throw Error("Supabase server environment is incomplete");
    if (!jwt || !apikey) return json({ error: "Authentication required" }, 401);

    const userClient = createClient(url, apikey, { global: { headers: { Authorization: authorization } }, auth: { persistSession: false, autoRefreshToken: false } });
    const ur = await userClient.auth.getUser(jwt);
    const user = ur.data.user;
    if (!user || ur.error) return json({ error: "Invalid or expired session" }, 401);
    const admin = createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });

    const input = await req.json();
    const orgId = String(input.organization_id || "");
    const manualId = String(input.manual_id || "");
    if (!orgId || !manualId) return json({ error: "organization_id and manual_id are required" }, 400);

    const member = await userClient.from("organization_members").select("role").eq("organization_id", orgId).eq("user_id", user.id).eq("active", true).maybeSingle();
    if (member.error || !member.data) return json({ error: "Active company membership required" }, 403);
    if (!["owner", "manager"].includes(String(member.data.role))) return json({ error: "Owner or manager permission required to index manuals" }, 403);

    const mres = await admin.from("manuals").select("id,title,mime_type,size_bytes,storage_path,status").eq("id", manualId).eq("organization_id", orgId).maybeSingle();
    if (mres.error || !mres.data) return json({ error: "Manual not found" }, 404);
    const manual = mres.data as any;
    if (String(manual.mime_type) !== "application/pdf") return json({ error: "AI indexing works on PDF files only (this file: " + String(manual.mime_type) + ")" }, 400);
    if ((manual.size_bytes || 0) > 20 * 1024 * 1024) return json({ error: "Manual is over 20 MB — split it into smaller PDFs first" }, 400);

    const { data: fileData, error: fe } = await admin.storage.from("plant-files").download(manual.storage_path);
    if (fe || !fileData) return json({ error: "Could not read the manual file from storage" }, 500);
    const fileBytes = new Uint8Array(await fileData.arrayBuffer());

    // ---- 1) upload the PDF to Gemini via the official MULTIPART endpoint ----
    const boundary = "pmpm" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    const enc = new TextEncoder();
    const head = `--${boundary}\r\nContent-Type: application/json\r\n\r\n${JSON.stringify({ file: { mimeType: "application/pdf" } })}\r\n--${boundary}\r\nContent-Type: application/pdf\r\nContent-Transfer-Encoding: binary\r\n\r\n`;
    const tail = `\r\n--${boundary}--\r\n`;
    const headB = enc.encode(head);
    const tailB = enc.encode(tail);
    const body = new Uint8Array(headB.length + fileBytes.length + tailB.length);
    body.set(headB, 0);
    body.set(fileBytes, headB.length);
    body.set(tailB, headB.length + fileBytes.length);

    const up = await fetch(`https://generativelanguage.googleapis.com/upload/v1beta/files?key=${encodeURIComponent(key)}`, {
      method: "POST",
      headers: { "Content-Type": `multipart/related; boundary=${boundary}` },
      body
    });
    const upJson: any = await up.json().catch(() => ({}));
    const fileUri = String(upJson.file?.uri || "");
    const fileId = String(upJson.file?.name || "").split("/").pop() || "";
    if (!up.ok || !fileId) return json({ error: "Gemini file upload failed: " + String(upJson.error?.message || up.status) }, 502);

    // ---- 2) wait until ACTIVE ----
    let fileState = "";
    for (let w = 0; w < 40 && !/ACTIVE/.test(fileState); w++) {
      await new Promise((r) => setTimeout(r, 3000));
      const st: any = await fetch(`https://generativelanguage.googleapis.com/v1beta/files/${fileId}?key=${encodeURIComponent(key)}`).then((r) => r.json().catch(() => ({})));
      fileState = String(st.file?.state || "");
      if (/FAILED/.test(fileState)) return json({ error: "Gemini could not process this PDF (it may be password-protected or corrupted)" }, 502);
    }
    if (!/ACTIVE/.test(fileState)) return json({ error: "Gemini is still processing the file — try indexing again in a minute" }, 503);

    const model = "gemini-3.1-flash-lite";
    const ask = async (prompt: string, maxOut: number) => {
      const g = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }, { file: { mimeType: "application/pdf", fileUri: fileUri || `https://generativelanguage.googleapis.com/v1beta/files/${fileId}` } }] }],
          generationConfig: { temperature: 0, maxOutputTokens: maxOut }
        })
      });
      const gj: any = await g.json().catch(() => ({}));
      const text = gj.candidates?.[0]?.content?.parts?.map((x: any) => x.text || "").join("") || "";
      if (!g.ok && !text) throw Error(`Gemini extraction failed: ${String(gj.error?.message || g.status)}`);
      return text;
    };

    // ---- 3) total page count ----
    const countText = await ask("How many pages does this PDF document have? Reply with ONLY the number.", 20);
    let totalPages = parseInt(countText.replace(/\D/g, ""), 10);
    if (!Number.isFinite(totalPages) || totalPages < 1) totalPages = 1;
    if (totalPages > MAX_PAGES) return json({ error: `Manual has about ${totalPages} pages (max ${MAX_PAGES}). Split it into smaller PDFs and index each part.` }, 400);

    // ---- 4) extract text in page batches, saving each batch as it completes ----
    const runStart = new Date().toISOString();
    let totalChunks = 0;
    for (let from = 1; from <= totalPages; from += BATCH_PAGES) {
      const to = Math.min(from + BATCH_PAGES - 1, totalPages);
      if (Date.now() - started > DEADLINE_MS) throw Error("Time limit reached mid-indexing. Completed pages were saved — press Index for AI again to finish the rest.");
      const text = await ask(
        `Extract the exact text of pages ${from} to ${to} of this technical manual. For EACH page output exactly this marker line first: [PAGE n]  (n is the page number), then that page's text. Keep table rows as plain text. Skip empty pages. No commentary.`,
        8192
      );
      const rows: { manual_id: string; page_number: number | null; content: string }[] = [];
      const pageMarker = /^\[PAGE\s*(\d+)\]/i;
      let curPage: number | null = null;
      let buf = "";
      const flush = () => {
        const t = buf.trim();
        if (t) for (let i = 0; i < t.length; i += 700) rows.push({ manual_id: manualId, page_number: curPage, content: t.slice(i, i + 700) });
        buf = "";
      };
      for (const line of text.split("\n")) {
        const m = pageMarker.exec(line.trim());
        if (m) { flush(); curPage = parseInt(m[1], 10) || null; }
        else buf += line + "\n";
      }
      flush();
      if (!rows.length && text.trim()) rows.push({ manual_id: manualId, page_number: from, content: text.trim().slice(0, 4000) });
      if (rows.length) {
        const ins = await admin.from("document_chunks").insert(rows);
        if (ins.error) throw Error("Saving chunks failed: " + ins.error.message);
        totalChunks += rows.length;
      }
    }

    // ---- 5) clean up older chunks from previous index runs of this manual ----
    await admin.from("document_chunks").delete().eq("manual_id", manualId).lt("created_at", runStart);
    await admin.from("manuals").update({ status: "indexed" }).eq("id", manualId);
    // clean up the temporary Gemini file
    await fetch(`https://generativelanguage.googleapis.com/v1beta/files/${fileId}?key=${encodeURIComponent(key)}`, { method: "DELETE" }).catch(() => {});
    return json({ ok: true, pages: totalPages, chunks: totalChunks, model, ms: Date.now() - started });
  } catch (e) {
    return json({ error: String((e as any)?.message || e) }, 500);
  }
});
