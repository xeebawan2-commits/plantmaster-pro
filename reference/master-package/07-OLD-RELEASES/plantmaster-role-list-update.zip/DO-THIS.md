# Role List Expansion — SQL first, then 4 files

Now the **Role** dropdown in Add Worker / Edit Worker includes ALL plant job titles:
worker, operator, assistant operator, senior operator, technician, senior technician,
checker, quality control officer, technical officer, senior technical officer, engineer,
mechanical engineer, electrical engineer, production engineer, utility engineer,
power house engineer, supervisor, store, assistant manager, deputy manager, manager,
admin officer, time officer, viewer.

New roles get normal member access; the owner can grant extra actions per person
("Granted actions" checkboxes in Edit & Permissions). Existing members are NOT changed.

## STEP 1 — Supabase SQL (DO THIS FIRST)

1. Supabase → **SQL Editor** (left sidebar) → New query
2. Paste the ENTIRE content of **`expand-roles.sql`**
3. **Run** (one-time change — makes the database accept the new roles)
4. Close the SQL editor

## STEP 2 — GitHub: upload these 4 files (same repo)

For each file: **Add file → Upload files → pick the file → Commit changes**

1. `app.js`        (replaces old — safe)
2. `operations.js` (replaces old — safe)
3. `index.html`    (replaces old — safe, keeps all previous scripts)
4. `designation-options.js` (re-upload is fine even if you already uploaded it before)

## STEP 3 — Test

Wait 1–2 minutes → close the app fully → reopen.
People → **Add worker** → tap **Role** → you'll see the full job-title list.
Pick e.g. "quality control officer" → save → the worker appears with that role.

⚠️ If you upload the files BEFORE running the SQL, saving a worker with a new role
will fail with a database error — so SQL first, always.
