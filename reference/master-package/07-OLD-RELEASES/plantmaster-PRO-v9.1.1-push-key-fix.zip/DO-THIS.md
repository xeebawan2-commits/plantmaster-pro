# PlantMaster Pro — v9.1.1: The final push fix

**What was broken (found by testing your actual VAPID key in code):**
The app's push module decoded the server key with a buggy function — it threw an error on
every phone, so the phone could never complete "Enable". This is why the bar never turned
green. Server side (SQL, function, token, poller) is all verified working — this was the last piece.

**What this package does (surgical, 3 files):**
- `push-client.js` v1.1.1 — fixed key decoding + now reports the real error in the toast if anything ever fails
- `app.js` v4.20.2 — toast shows the actual error reason
- `index.html` — version bumps for the above

---

## 1) GitHub — replace 3 files (~3 min)

Same repo (xeebawan2-commits/plantmaster-pro, branch main), same way as before
(open file → pencil ✏️ → select all → paste → Commit changes):

1. **push-client.js** ← new one from this zip
2. **app.js** ← new one from this zip
3. **index.html** ← new one from this zip

## 2) Phone test (~5 min)

1. Wait 1–10 min (GitHub Pages update) → open **hsbfix.org** in Chrome → refresh twice (⋮ → Refresh ×2)
2. Dashboard → the amber bar → tap **Finish setup** (or Enable alerts) → **Allow**
3. ⭐ Bar must turn **GREEN** + toast "✓ Alerts enabled on this phone"
   *(If it still fails, the toast now says WHY — screenshot it.)*
4. Supabase → SQL Editor → paste & Run:
   ```sql
   insert into public.notifications (organization_id, title, body)
   values ((select id from organizations limit 1), 'Push test',
           'If this appears on your phone lock screen, push is working end-to-end.');
   ```
5. GitHub → Actions → **Push poller** → **Run workflow ▾** → main → **Run workflow** (skip the 5-min wait)
6. Lock the phone → within ~60 s a **lock-screen notification** appears. Tap it → app opens on Alerts.
