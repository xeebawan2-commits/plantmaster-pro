# Voice Typing Fix — 3 files, zero editing

Everything is ready. You do NOT edit anything.

## GitHub — upload these 2 files (same repo as before)

1. **`voice-input.js`** → repo root
   - Add file → **Upload files** → pick `voice-input.js` → Commit changes
2. **`index.html`** → repo root (this file REPLACES the old one — that's safe and on purpose)
   - Add file → **Upload files** → pick `index.html` → Commit changes
   - Why replace it? Your current index.html accidentally lost the push-notification line when it was edited last time. This file has all 3 scripts back (app + push + voice, new version).

## Supabase — paste this 1 file

3. **`supabase-functions/index.ts`** → the voice-translate function
   - Supabase → Edge Functions → `voice-translate` → **Code** tab
   - Delete everything in the editor → paste the whole file → **Deploy**

## Then
Wait 1–2 minutes, open the app (close it fully and reopen once).
Test: hold the 🎙 (اردو) → say "log book likhni hai" → should type **"Need to write the log book"**.

Note: pushing notifications will start working again for new visitors because the push line is restored.
