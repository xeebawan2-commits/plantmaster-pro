# PlantMaster Pro — Push + Daily Email + Pro Theme: Deploy Guide

**What this package adds (v1.0.0, all additive — nothing existing is broken by design):**
1. **Professional theme** — the app now looks like the landing page (login screen, header, cards, tables, toasts). One CSS file, removable in one line.
2. **System push notifications** — work-order & alarm alerts on the phone's lock screen **even when the app is closed** (Web Push / FCM).
3. **Automated daily email** — every company with an email in its Company Profile gets a branded morning summary via Resend, sent by a free GitHub cron (11:00 PKT).

---

## A. App files → `plantmaster-pro` repo (GitHub)

| File | Action |
|---|---|
| `app/index.html` | **Replace** (adds 2 lines: theme CSS + push script; every existing ID untouched) |
| `app/theme-pro.css` | **Add** (new file) |
| `app/push-client.js` | **Add** (new file) |
| `app/service-worker.js` | **Replace** (v4.11.1 base + push handlers, cache v4.12.0) |
| `app/app.js` | **Replace** — ONLY change: service-worker registration `?v=4.7.2` → `?v=4.12.0` (so phones pick up the new SW immediately). The attached `app.js` is your file with that single string replaced — verify with `git diff` before committing. |

> After push to GitHub Pages, hard-refresh one phone (or wait for the 10-min Pages cache) — installed PWAs update on next launch when the SW version changes.

## B. Supabase → SQL

Dashboard → **SQL Editor → New query** → paste `sql/20-push-and-email.sql` → **Run**.
Creates `push_subscriptions`, `push_cursors` (RLS on, no policies → only your edge functions can touch them), an index on notifications, and a trigger that auto-creates a cursor for new companies. Idempotent — safe to re-run.

## C. Supabase → Edge functions

CLI (or Dashboard → Edge Functions → New):

```bash
supabase functions deploy web-push
supabase secrets set VAPID_PUBLIC_KEY="BH9ogu3zE6LfOW6yp4oQs372lm61ySttCWXO4hYe6Rn5LGrwKL2jrZf1hYVpx_bnh_vIHxJ8YEdeyrPmdMBcpcg" \
                     VAPID_PRIVATE_KEY="6QadGnijBo-BURW040ufXGN_6J3aGYfB2QAsD1zY_5w" \
                     VAPID_SUBJECT="mailto:hello@plantmasterpro.com" \
                     PUSH_INTERNAL_TOKEN="$(openssl rand -hex 24)"

supabase functions deploy daily-reports
supabase secrets set DAILY_REPORTS_TOKEN="$(openssl rand -hex 24)" \
                     RESEND_API_KEY="re_xxxxxxxxxxxx" \
                     DAILY_REPORTS_FROM="PlantMaster Pro <reports@plantmasterpro.com>"
```

**⚠️ Note on the VAPID keys:** the pair above was generated for you and is already embedded in `push-client.js` (public key). The **private key goes only into the function secrets** — never commit it. If you ever re-deploy to a new project, run `npx web-push generate-vapid-keys` and update both places.

## D. Resend (free tier: 3 emails/hour, 100/day)

1. sign-up at **resend.com** (free)
2. **Domains → Add Domain** → `plantmasterpro.com` → add the TXT record it shows in your registrar's DNS (this is the "hello@plantmasterpro.com" step from the launch guide — one DNS record covers both)
3. Copy the API key (`re_...`) → into the secrets above

## E. GitHub → cron triggers (free)

1. Copy both files from `workflows/` into the `plantmaster-pro` repo as **`.github/workflows/push-poller.yml`** and **`.github/workflows/daily-reports.yml`**
2. Repo → Settings → Secrets and variables → Actions → add:

| Secret | Value |
|---|---|
| `PUSH_FN_URL` | `https://dpmmenwziplixrgylapy.supabase.co/functions/v1/web-push` |
| `PUSH_INTERNAL_TOKEN` | the same token from step C |
| `SUPABASE_ANON_KEY` | the publishable key from `config.js` |
| `DAILY_REPORTS_FN_URL` | `https://dpmmenwziplixrgylapy.supabase.co/functions/v1/daily-reports` |
| `DAILY_REPORTS_TOKEN` | the same token from step C |

3. Push → the poller runs every 5 minutes; daily reports at 11:00 PKT. (New Actions are disabled on fresh repos — flip the switch in **Actions → General → Workflow permissions**.)

## F. Test checklist (do this once, ~20 minutes)

**Push**
- [ ] Open the app on a phone → sign in → the **"Enable alerts"** banner appears (bottom-left) → tap **Enable** → allow notifications
- [ ] In Supabase SQL editor: `insert into public.notifications (organization_id, plant_id, title, body) values ('<your-org-id>', null, 'Push test', 'If you read this on the lock screen, push works.');`
- [ ] Within 5 minutes the phone shows the notification; tapping it opens the app on the Alerts view
- [ ] On a *second* phone of the same company: same test (multi-user works)
- [ ] **Later** = banner hidden for 24 h; uninstall/reinstall or clearing site data re-shows it

**Daily email**
- [ ] Put a real inbox in **Company Profile → Company email** of a test company
- [ ] Actions → `Daily reports` → **Run workflow** (don't wait 11:00) → Inbox within ~1 minute
- [ ] Check the summary numbers match the Dashboard KPIs

**Theme**
- [ ] Login screen shows the new premium panel + gear mark
- [ ] A company that set custom brand colours (Company Profile) still shows its own colours on buttons/active states

## G. What I verified vs. what you verify live
Verified in this package (automated): syntax of every JS/TS file, CSS integrity, HTML structure of the new index.html (all original element IDs preserved), VAPID keypair format, SQL idempotency.
You verify live (needs your Supabase + a phone): the test checklist above. Every component degrades safely: if push isn't configured, the app runs exactly as today; if Resend fails, the workflow log shows the error and nothing else is affected.

## H. Later upgrades (not needed now)
- Push trigger < 5 min → enable `pg_net` in Supabase + a DB trigger on work_orders (I can write it when you want true real-time push)
- Per-company send time (each org's `report_time`) → currently one shared 11:00 PKT run
- More email volume → Brevo free (300/day) — swap is 5 lines in `daily-reports/index.ts`
- Push for work-order assignment specifically (not just the notifications table) → small DB trigger, phase 2
