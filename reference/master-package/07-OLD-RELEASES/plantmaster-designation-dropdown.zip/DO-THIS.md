# Designation Dropdown — 2 files, zero editing, no Supabase change

Now the **Designation** box shows a dropdown of all plant job titles wherever it appears
(Add Worker, Edit Worker, Work Done, and every future screen that uses it).
Tap to pick from the list, or type any custom title — free typing still works.

## Options included
Worker · Operator · Assistant Operator · Senior Operator · Technician · Senior Technician ·
Checker · Quality Control Officer · Technical Officer · Senior Technical Officer ·
Engineer · Mechanical Engineer · Electrical Engineer · Production Engineer ·
Utility Engineer · Power House Engineer · Supervisor · Assistant Manager · Deputy Manager ·
Manager · Admin Officer · Time Officer

## Upload (GitHub only — do NOT touch Supabase)

1. **`designation-options.js`** → repo root
   - Add file → **Upload files** → pick `designation-options.js` → Commit changes
2. **`index.html`** → repo root (replaces the old one — safe and on purpose)
   - Add file → **Upload files** → pick `index.html` → Commit changes
   - This file keeps all previous scripts (app + push + voice v1.1.0) and adds the new one.

## Test
Wait 1–2 minutes → close the app fully → reopen.
Roster & Attendance (More → People) → Add worker → tap **Designation** → the dropdown appears.
Set it on a worker's profile (Edit & Permissions), and it auto-stamps on their work completions,
logs, checklists, stock transactions and handovers.

Note: the separate "Workspace role" dropdown (owner/manager/engineer/supervisor/technician/store/viewer)
is the APP PERMISSIONS — it controls what a person can do. Designation is their real job title.
