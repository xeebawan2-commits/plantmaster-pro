# 🎙 Voice Typing Update (v4.13)

A microphone button appears in **every screen** of the app. Tap any text box, then tap the 🎙:

- **Tap 🎙** → speak in **English** (default) → words appear in the box
- **Long-press 🎙** (hold 1 sec) → switch to **اردو** → speak Urdu → it is **typed in English** (your original Urdu is shown briefly so you can check it)
- Long-press again to switch back to English
- Works in: search box, every Add form, work order notes, asset fields, condition notes, scanner notes, Problem Solver, support tickets — anywhere you type
- If translation can't run (no internet / no Gemini key), your **Urdu words are still saved** in the box — nothing is ever lost
- The Problem Solver's own voice button still works as before

**Prerequisite:** the `GEMINI_API_KEY` secret must be in Supabase (your main goal — do that first).

---

## Deploy — 3 steps (all from your phone)

### Step 1 — GitHub: add the new file
1. Open your repo on github.com (the one with `plantmaster-pro`)
2. Top of the file list: **Add file → Upload files**
3. Pick **`voice-input.js`** from your phone's downloads
4. **Commit changes** (bottom button)

### Step 2 — GitHub: one line in index.html
1. In the repo, tap **`index.html`** → tap the **pencil ✏️ icon** (Edit this file)
2. Press `End` / scroll to the very end of the file. Find this last line:
   `<script type="module" src="push-client.js?v=1.0.0"></script></body></html>`
3. Add ONE new line right before `</body>`:
   ```html
   <script type="module" src="voice-input.js?v=1.0.0"></script>
   ```
   So the end becomes:
   `<script type="module" src="push-client.js?v=1.0.0"></script><script type="module" src="voice-input.js?v=1.0.0"></script></body></html>`
4. **Commit changes**

### Step 3 — Supabase: the translator function
1. Supabase → **Edge Functions → New Function**
2. Name it exactly: `voice-translate`
3. Paste the **entire content of `voice-translate/index.ts`** into the editor
4. **Deploy**
5. In the function's settings: **Verify JWT stays ON** (unlike web-push/daily-reports — this one is called from the app with your user login)
6. No new secrets needed — it reuses `GEMINI_API_KEY`

### Wait 1–2 minutes
GitHub Pages rebuilds. Then open the app: tap any text box → the blue 🎙 button (bottom right) → speak.

---

## Test list
| # | Test | Expected |
|---|------|----------|
| 1 | Any screen → tap search box → tap 🎙 → say "pump number three making noise" | English text typed into the box |
| 2 | Long-press 🎙 (badge shows اردو) → tap → speak in Urdu | English translation typed, your Urdu shown briefly below |
| 3 | Long-press 🎙 again | Badge back to EN |
| 4 | Problem Solver → its own voice button | Still works, unchanged |

## If something's off
- **No 🎙 button at all** → close the app completely, reopen (new service worker). Must be Chrome + HTTPS.
- **Mic flashes but no text** → speak a little louder / closer; "Nothing heard" = Google didn't catch speech.
- **"Conversion unavailable"** → Gemini key missing or invalid → Supabase → Edge Functions → Secrets → check `GEMINI_API_KEY`.
- **Old look/behavior** → refresh once in Chrome, reopen the app.
