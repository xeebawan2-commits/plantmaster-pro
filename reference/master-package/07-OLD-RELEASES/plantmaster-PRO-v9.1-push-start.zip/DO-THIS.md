# PlantMaster Pro — v9.1: Make push notifications actually start

**What was wrong (verified from your live server, all 3 found and fixed here):**
1. The app's "Enable alerts" bar never turned green after you tapped Enable (my bug) — so you could not tell if it worked.
2. A column the push server reads (`notifications.severity`) was never created — every push poll failed **silently**.
3. The 5-minute "push poller" job was never added to your GitHub repo — so nothing ever asked the server to send.

Everything else (service worker, web-push function, VAPID keys, v9 files) is confirmed working on your live site. **No other app changes** — only 2 files replaced + 2 new files + 1 SQL script.

---

## PART 1 — Supabase (≈2 min)

1. Open **supabase.com** → your project → left menu **SQL Editor** → **New query**.
2. Open **push-setup.sql** from this zip → copy ALL of it → paste → tap **Run**.
   (It fixes the missing column + confirms the push tables exist. Safe to run.)
3. Left menu **Edge Functions** → tap **web-push** → **Settings** tab → **Environment variables & Secrets** → add (or update) a secret:
   - Name: `PUSH_INTERNAL_TOKEN`
   - Value: `84006c835509f1a0fdfd9376ed36844e3bfff4d9d63e06df`
   (This exact value is also inside push-poller.yml below — they must match.)

## PART 2 — Add the 5-minute poller to GitHub (≈3 min)

1. Open **github.com** → repo **xeebawan2-commits/plantmaster-pro** → branch **main**.
2. Tap **Add file** → **Create new file**.
3. In the "Start naming your file…" box type EXACTLY (including the dots and slashes — GitHub creates the folders for you):
   `.github/workflows/push-poller.yml`
4. Paste the ENTIRE content of **push-poller.yml** from this zip → **Commit changes**.
5. Tap the **Actions** tab (top of repo). You should see **Push poller**.
   - If GitHub says Actions are disabled: **Settings** → **Actions** → **General** → **Workflow permissions** → enable → save. (Free on public repos.)

## PART 3 — Replace 2 app files (≈2 min)

Same place where you uploaded v9 (root of the plantmaster-pro repo):
1. Replace **app.js** with the new one from this zip (open file → pencil ✏️ → select all → paste → Commit changes).
2. Replace **index.html** the same way.

## PART 4 — Test on your phone (≈10 min)

1. Wait 1–10 minutes (GitHub Pages update time). Open the app in Chrome.
   If the old version still shows: Chrome menu ⋮ → **Refresh** (twice).
2. Dashboard → the amber bar → tap **Enable alerts** → when Android asks, tap **Allow**.
3. ✅ The bar must turn **GREEN** ("Push alerts enabled") right away + toast "✓ Alerts enabled on this phone".
4. **The final proof** — Supabase → SQL Editor → paste & Run:
   ```sql
   insert into public.notifications (organization_id, title, body)
   values ((select id from organizations limit 1), 'Push test',
           'If this appears on your phone lock screen, push is working end-to-end.');
   ```
5. Close the app / lock the phone. Within ~5 minutes a lock-screen notification appears. Tapping it opens the app on the Alerts screen.

## If the test notification does not appear in 10 minutes

GitHub → repo → **Actions** tab → **Push poller** → tap the latest run → read the log line:
- `{"ok":true,"orgs_touched":1,"sent":1,...}` → it sent. If nothing on the phone, the phone never completed "Allow" — redo PART 4 step 2.
- `{"error":"Forbidden"}` → the token in the workflow ≠ the function secret → redo PART 1 step 3 exactly.
- Run failing to start → Actions disabled → PART 2 step 5.

Screenshot whatever you see and send it — I will read it.
