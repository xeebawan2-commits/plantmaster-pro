# AI Indexing Fix v3 — RESUME THE UPLOAD THE WAY GOOGLE WANTS IT NOW

Only ONE file changed: `supabase-functions/ingest-manual.ts`
(your app.js v4.15 and index.html are already live — do NOT touch them).

## What was wrong
Google now REQUIRES a 2-step "resumable" upload for the Files API —
simple one-shot uploads are rejected (your "400" error). This version
uses the official protocol from Google's current documentation, and it
also reports the exact Gemini error message if anything else is off.

## Deploy (1 step)
1. Supabase → Edge Functions → **ingest-manual** → **Code** tab
2. Delete everything → paste the ENTIRE file `supabase-functions/ingest-manual.ts` → **Deploy**
3. Verify JWT stays ON. No secrets changed.

## Test
- Wait ~1 minute → close the app fully → reopen
- Manuals → tap 🤖 Index for AI on `9829305005.pdf`
- Card shows **indexing…** → then "Done — N text chunks ready" toast → status **indexed**
- Then try `DESCALING PROCEDURE.pdf` too
- Finally ask the Problem Solver a question from the manual — expect "manual — page n" citations

## If it still fails (it shouldn't)
The toast now shows Gemini's EXACT error message — screenshot it and send it.
