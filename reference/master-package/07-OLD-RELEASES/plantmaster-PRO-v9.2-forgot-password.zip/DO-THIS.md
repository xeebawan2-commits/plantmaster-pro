# PlantMaster Pro — v9.2: Forgot Password

Adds a "Forgot password?" link on the sign-in screen + a "Set a new password" screen.
This permanently replaces the old dead recovery links (they pointed to localhost:3000).

**Replace 2 files** (same repo, same way: open → ✏️ → select all → paste → Commit):
1. `app.js`     ← from this zip
2. `index.html` ← from this zip

**Test (5 min):**
1. Wait 1–10 min → open hsbfix.org → refresh twice
2. **Logout** (or open a private window)
3. Type your account email → tap **Forgot password?** (blue link under the form)
4. Check that email's inbox → "Recovery email sent" → tap the link in it
5. A **"Set a new password"** screen appears → enter new password twice → **Set password**
6. ✅ Straight into the app, signed in
7. Log out → sign in again with the **new** password → works

No SQL, no Supabase changes, no other files.
