# AI Indexing Fix v4 — big-file auto-retry (the final piece)

## What was happening (your screenshot proved it)
The upload to Gemini now WORKS. Small PDFs (like DESCALING PROCEDURE) index
fine. The 14.8 MB one failed only because a PDF that big takes Gemini more
than 2 minutes to finish processing, and the old function gave up.

## What this version does
1. The function now SAVES PROGRESS page-by-page and can RESUME.
2. If Gemini is "still processing" (or time runs out mid-way), the APP
   automatically waits 45 seconds and tries again — up to 4 times — all in
   the background. The card shows: indexing… → indexing… (retry 1) → … → indexed.
3. On retry, pages already done are SKIPPED — no wasted work.
4. The 🤖 Index for AI button now does a FULL re-index.

## Deploy (3 steps)
1. Supabase → Edge Functions → **ingest-manual** → Code tab →
   delete all → paste entire `supabase-functions/ingest-manual.ts` → **Deploy** (Verify JWT ON)
2. GitHub → upload `app.js` → Commit
3. GitHub → upload `index.html` → Commit

## Test
- Wait ~1 minute → close app fully → reopen
- Tap 🤖 Index for AI on `9829305005.pdf`
- Watch the card: indexing… (maybe "(retry 1)" or "(retry 2)") → indexed
- This can take 2–5 minutes total — leave the app open, you can keep using it
- Then ask the Problem Solver a question from the manual — expect
  "manual — page n" citations
