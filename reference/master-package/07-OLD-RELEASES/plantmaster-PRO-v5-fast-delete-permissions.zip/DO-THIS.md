# PlantMaster Pro v5 — FASTER AI indexing + Delete + "who can see manuals"

## What's new
1. **MUCH faster indexing**
   - PDFs up to 4 MB (like your DESCALING + Dryer Part manuals) now go
     STRAIGHT to Gemini inline — no upload wait. ~20–40 seconds each.
   - Bigger manuals: bigger page batches, 2 batches at a time, progress saved,
     automatic background retries. 14.8 MB manual ≈ 2–4 minutes.
   - Indexing jobs now run ONE AT A TIME (queue) — this is why small ones
     were slow: they were all fighting each other inside Gemini.
   - Any manual still sitting as "uploaded" starts indexing automatically
     the next time you open the Manuals page (owner/manager).
2. **🗑 Delete button** on every manual card (owner/manager only) — removes
   the file, the AI index and all records.
3. **Admin control: who can see manuals**
   - People → Members → "Edit & Permissions" → new checkbox:
     "📚 Can view Manuals & Drawings (and their AI index)"
   - Untick it → that worker can no longer open the Manuals section
     (and can't search manual pages in the Problem Solver either).
   - Default = everyone can see (nothing breaks). Owner & manager always can.

## Deploy (in this order)

**Step 1 — SQL (the permission lock):**
Supabase → SQL Editor → New query → paste entire `sql/manual-access.sql` → Run

**Step 2 — Supabase Edge Functions:**
- `ingest-manual` → Code tab → delete all → paste entire
  `supabase-functions/ingest-manual.ts` → Deploy (Verify JWT ON)
- New Function → name it **`delete-manual`** → paste entire
  `supabase-functions/delete-manual.ts` → Deploy → Verify JWT **ON**

**Step 3 — GitHub (3 files):**
- upload `app.js` → Commit
- upload `operations.js` → Commit
- upload `index.html` → Commit

## Test
- Wait ~1 minute → close app fully → reopen
- Manuals: your small manuals should index fast on their own (status → indexed)
- 🗑 Delete: delete any test manual → it disappears
- Permission: People → pick a test member → Edit & Permissions → untick
  "Can view Manuals" → Sign out/in as that member → Manuals section is gone
