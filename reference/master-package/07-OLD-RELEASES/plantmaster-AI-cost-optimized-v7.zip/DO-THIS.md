# AI Indexing v7 — CHEAPER (no app changes, function only)

## What was costing money
Every page-batch call sends the WHOLE manual to Gemini, and Gemini bills the
whole document per call. The old version did that ~7 times for a big manual
(1 count call + 6 batches). v7 does it only ~4 times (count is folded into
the first batch, batches are 40 pages instead of 25).
=> big-manual indexing cost drops roughly 40%.

## Deploy (1 step)
Supabase → Edge Functions → **ingest-manual** → Code tab → delete all →
paste entire `supabase-functions/ingest-manual.ts` → **Deploy** (Verify JWT ON)

## Your costs in real money (Gemini flash-lite)
- One AI question (Problem Solver):  ~$0.0002  (about 5,000 questions per $1)
- One voice command:                 ~$0.00002
- Index a small manual (<12 MB):     ~$0.01–0.03, once
- Index a big manual (14.8 MB):      ~$0.05–0.15, once (v7)
Indexing is a ONE-TIME reading cost per manual. Questions after it are
essentially free. With your $10 top-up you could index thousands of manuals.
